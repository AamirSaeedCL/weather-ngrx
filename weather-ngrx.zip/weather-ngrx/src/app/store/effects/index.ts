import { WeatherEffects } from "./weather.effects";


export const effects: any[] = [WeatherEffects];
export * from "./weather.effects";